import json
import numpy as np
import onnxruntime as ort
from PIL import Image

MEAN = np.array([0.485, 0.456, 0.406], dtype=np.float32)
STD = np.array([0.229, 0.224, 0.225], dtype=np.float32)
IMG = 224

class Classifier:
    def __init__(self, model_path='model.onnx', labels_path='labels.json'):
        self.sess = ort.InferenceSession(model_path, providers=['CPUExecutionProvider'])
        self.labels = json.load(open(labels_path, encoding='utf-8'))

    def predict(self, image, top_k=3):
        img = image.convert('RGB').resize((IMG, IMG))
        x = (np.asarray(img, dtype=np.float32) / 255.0 - MEAN) / STD
        x = np.transpose(x, (2, 0, 1))[None].astype(np.float32)
        logits = self.sess.run(None, {'input': x})[0][0]
        e = np.exp(logits - logits.max())
        probs = e / e.sum()
        top = probs.argsort()[::-1][:top_k]
        return [(self.labels[i], float(probs[i])) for i in top]
